<ul class="right hide-on-med-and-down">
        <li><a href="vender.php">Vender</a></li>
        <li><a href="comprar.php">Comprar</a></li>
        <li><a href="registrar0cliente.php">Registrar Cliente</a></li>
      </ul>