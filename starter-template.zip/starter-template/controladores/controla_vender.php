<?php
$prenda = $_POST["prenda"];
$cantidad = $_POST["cantidad"];
if($cantidad > 0)
{
//aca cuando si
echo "La prenda es ".$prenda;
echo "<br> La cantidad es ".$cantidad;
}else
{//aca cuando no
echo "valor invalido";
}
?>