<?php
$cantidad = $_POST["cant"];
$total = $_POST["totall"];
if($cantidad > 0 and $total > 0)
{
//aca cuando si
echo "La cantidad es ".$cantidad;
echo "<br> El valor pagado es ".$total;
}else
{//aca cuando no
echo "Valor invalido";
}
?>