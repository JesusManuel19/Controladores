<?php
$nombre = $_POST["nombre"];
$apellido = $_POST["apellido"];
$celular = $_POST["celular"];
$edad = $_POST["edad"];
if($edad > 17)
{
//aca cuando si
echo "El nombre es ".$nombre;
echo "<br> El apellido es ".$apellido;
echo "<br> El celular es ".$celular;
echo "<br> La edad es ".$edad;
}else
{//aca cuando no
echo "Es menor de edad";
}
?>