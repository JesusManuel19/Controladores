<?php
$cantidad = $_POST["cant"];
$total = $cantidad * 2500;
if($total > 0 and $total < 100000)
{
//aca cuando si
echo "el total a pagar es ".$total;
}else
{//aca cuando no
echo "valor invalido";
}
?>