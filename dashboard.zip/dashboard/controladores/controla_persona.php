<?php
$nombre = $_POST["nombre"];
$descripción = $_POST["desc"];
$edad = $_POST["edad"];
if($edad >= 18)
{
//aca cuando si
echo "nombre: ".$nombre;
echo "<br> doc: ".$documento;
echo "<br> edad: ".$edad;
}else
{//aca cuando no
echo "chao";
}
?>